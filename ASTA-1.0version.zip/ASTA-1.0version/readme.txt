This is the adaptive state transition algorithm with local enhancement for global optimization (ASTA)
The main function is Test_asta.
You are suggested to cite the following references if you are using the ASTA.

1) Y.C Dong, H.L. Zhang, C. Wang, X.J. Zhou, An adaptive state transition algorithm with local 
enhancement for global optimization, Applied Soft Computing, 2022, Accepted
2) X.J. Zhou, C.H. Yang and W.H. Gui, State Transition Algorithm, 
Journal of Industrial and Management Optimization 8(4): 1039-1056, 2012.
3) X.J. Zhou, C.H. Yang, W.H. Gui, A Statistical Study on Parameter Selection of Operators in 
Continuous State Transition Algorithm, IEEE Transactions on Cybernetics, 49(10):3722-3730,2019.

Contact Information��
Dr. Yingchao Dong
PhD
School of Electrical Engineering,
Xinjiang University,
Urumqi, Xinjiang, P.R. China 
830047
dycxju@163.com

The matlab codes are run under the Matlab 2018b. Please do not hesitate to contact me if you have any further questions.
