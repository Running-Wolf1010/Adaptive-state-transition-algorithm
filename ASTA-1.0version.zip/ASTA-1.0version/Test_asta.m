%**************************************************************************************************
%Author: Yingchao Dong, Hongli Zhang, Cong Wang, Xiaojun Zhou
%Last Edited: Mar 18, 2022
%Email: dycxju@163.com
%Reference: An adaptive state transition algorithm with local enhancement for global optimization
%                            Applied Soft Computing, 2022, Accepted
%**************************************************************************************************
clear all
clc
currentFolder = pwd;
addpath(genpath(currentFolder))

% parameter setting
Dim =100; % dimension
SE = 30;   % degree of search enforcement
Maxiter = 500;% maximum number of iterations
Range = repmat([-30;30],1,Dim); %range
tic
[Best,fBest,history] = ASTA(@Rosenbrock,SE,Dim,Range,Maxiter);
toc
semilogy(history)





