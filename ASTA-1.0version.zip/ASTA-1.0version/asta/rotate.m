function [Best,fBest] = rotate(funfcn,oldBest,fBest,SE,Range,alpha,beta)

Best = oldBest;
State = op_rotate(Best,SE,alpha); %rotation operator
State = bound(Range,State);
[newBest,fGBest] = selection(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;
end

if flag ==1   
    State = op_translate(oldBest,Best,SE,beta);
    State = bound(Range,State);
    [newBest,fGBest] = selection(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;
    end
end

end