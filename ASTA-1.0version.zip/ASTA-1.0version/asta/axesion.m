function [Best,fBest] = axesion(funfcn,oldBest,fBest,SE,Range,beta,delta)

Best = oldBest;
State = op_axes(Best,SE,delta); %axesion operator
State = bound(Range,State);
[newBest,fGBest] = selection(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;
end

if flag ==1  
    State = op_translate(oldBest,Best,SE,beta);
    State = bound(Range,State);
    [newBest,fGBest] = selection(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;
    end
end

end
