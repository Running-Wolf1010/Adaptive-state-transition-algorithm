function [Best,fBest] = adaption(funfcn,oldBest,fBest,SE,Range,Omega)
% Adaptive selection of optimal operators and parameters

beta = 1;
Best = oldBest;

m = length(Omega);
Dim = length(Best);
State1 = zeros(m*SE,Dim);
State2 = zeros(m*SE,Dim);
State3 = zeros(m*SE,Dim);
for i = 1:m
    x1 = op_expand(Best,SE,Omega(i)); %expansion operator
    State1 = [State1(SE+1:end,:);x1];
    x2 = op_rotate(Best,SE,Omega(i)); %rotation operator
    State2 = [State2(SE+1:end,:);x2];
    x3 = op_axes(Best,SE,Omega(i));   %axesion operator
    State3 = [State3(SE+1:end,:);x3];
end

State1 = bound(Range,State1);
State2 = bound(Range,State2);
State3 = bound(Range,State3);
k = size(State1,1);
fState1 = zeros(k,1);
fState2 = zeros(k,1);
fState3 = zeros(k,1);
for i = 1:k
    fState1(i,:) = feval(funfcn,State1(i,:));
    fState2(i,:) = feval(funfcn,State2(i,:));
    fState3(i,:) = feval(funfcn,State3(i,:));
end

rate1 = sum(fState1<fBest)/k;
rate2 = sum(fState2<fBest)/k;
rate3 = sum(fState3<fBest)/k;
rate = [rate1,rate2,rate3]./(rate1+rate2+rate3+1e-300);%success rate

if rate1==0
    Grad1=0;
else
    Grad1=abs((mean(fState1(fState1<fBest))-fBest)/fBest);
end

if rate2==0
    Grad2=0;
else
    Grad2=abs((mean(fState2(fState2<fBest))-fBest)/fBest);
end

if rate3==0
    Grad3=0;
else
    Grad3=abs((mean(fState3(fState3<fBest))-fBest)/fBest);
end

Grad=[Grad1,Grad2,Grad3]./(Grad1+Grad2+Grad3+1e-300);%descent rate

[~,index] = max(rate.*0.5+Grad.*0.5);%comprehensive evaluation indexes

State = [State1;State2;State3];
fState = [fState1;fState2;fState3];

[newfBest,g] = min(fState);
oldBest = State(g,:);
if newfBest < fBest
    fBest = newfBest;
    Best = oldBest;
end

switch index
case 1
    [~,g1] = min(fState1);
    index_best = ceil(g1/SE);
    gamma = Omega(index_best);
    for i = 1:10
        [Best,fBest]=expand(funfcn,Best,fBest,SE,Range,beta,gamma);
    end

case 2
    [~,g2] = min(fState2);
    index_best = ceil(g2/SE);
    alpha = Omega(index_best);
    for i = 1:10
        [Best,fBest]=rotate(funfcn,Best,fBest,SE,Range,alpha,beta);
    end

case 3
    [~,g3] = min(fState3);
    index_best = ceil(g3/SE);
    delta = Omega(index_best);
    for i = 1:10
        [Best,fBest]=axesion(funfcn,Best,fBest,SE,Range,beta,delta);
    end
end

end