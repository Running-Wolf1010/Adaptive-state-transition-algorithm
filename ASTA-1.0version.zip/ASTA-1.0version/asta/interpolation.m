function [Best,fBest] = interpolation(funfcn,history_Best,history_fBest,Range)

Best = history_Best(end,:);
fBest = history_fBest(end);

State = op_interpolation(history_Best,history_fBest);
State = bound(Range,State);
[newBest,fGBest] = selection(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
end


