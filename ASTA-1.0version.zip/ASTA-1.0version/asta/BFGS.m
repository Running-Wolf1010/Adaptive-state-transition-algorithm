function [xk,oldf] = BFGS(func,xk,Range)
% quasi-Newton method

epsilon = 1e-10; %accuracy threshold 
iter = 30; %Maximum number of iterations

oldf = feval(func,xk);
Bk = eye(length(xk));% hessian
grad = fgrad(func,xk); % gradient

for t = 1:iter
    
    dk = -Bk\grad; % direction
    ak = armijo(func,xk,dk,grad);% step
    new_xk = xk + ak*dk'; 
    new_xk = bound(Range,new_xk);
    newf = feval(func,new_xk);
    new_grad = fgrad(func,new_xk); % gradient

    if(norm(grad)<epsilon)
        break;
    end
   
    yk = new_grad - grad;
    sk = new_xk' - xk';
    
    if(yk'*sk>0)
        Bk = Bk - (Bk*sk*sk'*Bk)/(sk'*Bk*sk) + (yk*yk')/(yk'*sk);
    end
    
    if newf < oldf
        xk = new_xk;
        oldf = newf;
        grad = new_grad;
    end
    
end

end

function df = fgrad(func,x)
% Calculating the gradient
h = 1e-10;
n = length(x);
y1 = feval(func,x);
x2 = repmat(x,length(x),1) + eye(length(x))*h;
y2 = zeros(n,1);
for i = 1:n
    y2(i,:) = feval(func,x2(i,:));
end
df = (y2-y1)/h;
end

function ak = armijo(func,xk,dk,grad)
% Armijo Non-exact line search to obtain iteration steps
rho = 0.55; 
sigma = 0.4;
m = 0; 
mk = 0;
while(m<20)
if(feval(func,xk+rho^m*dk')<feval(func,xk)+sigma*rho^m*grad'*dk)
    mk = m; break;
end
m = m + 1;
end
ak = rho^mk;
end
