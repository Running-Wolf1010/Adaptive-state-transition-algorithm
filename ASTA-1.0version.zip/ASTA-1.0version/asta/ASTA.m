function [Best,fBest,history] = ASTA(funfcn,SE,Dim,Range,Maxiter)

rand('seed', sum(100 * clock));
% parameter setting
Omega = [1,0.5,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8];

% initialization
State = initialization(SE,Dim,Range);
[Best,fBest] = selection(funfcn,State);
history(1) = fBest;

% Store the history solution
history_num = 6;
history_Best = rand(history_num,Dim); 
history_fBest = rand(history_num,1); 

iter = 1;
% iterative process
while iter < Maxiter
    
    % Adaptive selection for search iteration process
    [Best,fBest] = adaption(funfcn,Best,fBest,SE,Range,Omega);
    
    history_Best = [history_Best(2:end,:);Best];
    history_fBest = [history_fBest(2:end,:);fBest];
    
    xi = mean(abs((history_fBest(1:end-1)-fBest)./(fBest+1e-300)));
    mu = mean(abs(history_fBest(1:end-1)-fBest));

    % BFGS for local enhancement
    if 0 < xi && xi < 0.1
        [Best,fBest] = BFGS(funfcn,Best,Range); 
        history_Best = [history_Best(2:end,:);Best];
        history_fBest = [history_fBest(2:end,:);fBest];
    end

    % Quadratic interpolation for local enhancement
    if 0 < mu && mu < 1e-6
        [Best,fBest] = interpolation(funfcn,history_Best,history_fBest,Range);   
        history_Best = [history_Best(2:end,:);Best];
        history_fBest = [history_fBest(2:end,:);fBest];
    end
    
    iter = iter + 1;
    
    fprintf('iter=%d  ObjVal=%g\n',iter,fBest);
     
    history(iter) = fBest;
    
end

end
