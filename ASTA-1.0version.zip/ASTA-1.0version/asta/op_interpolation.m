function State = op_interpolation(history_Best,history_fBest)
% Quadratic interpolation

[g,dim] = size(history_Best);
State = zeros(g,dim);

Best = history_Best(g,:);
fBest = history_fBest(g);

for i = 1:g
    
    rand_num = randperm(g-1);
    r1 = rand_num(1);
    r2 = rand_num(2);
    y = history_Best(r1,:);
    z = history_Best(r2,:);
    fy = history_fBest(r1);
    fz = history_fBest(r2);
    
    State(i,:) = 0.5.*((y.^2-z.^2)*fBest+(z.^2-Best.^2)*fy+(Best.^2-y.^2)*fz)./((y-z)*fBest+(z-Best)*fy+(Best-y)*fz);

    temp = State(i,:);
    temp(isnan(State(i,:))) = Best(isnan(State(i,:)));   
    
    State(i,:) = temp;
    
end
