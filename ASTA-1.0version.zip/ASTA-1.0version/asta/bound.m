function State = bound(Range,State)
Pop_Lb = repmat(Range(1,:),size(State,1),1);
Pop_Ub = repmat(Range(2,:),size(State,1),1);
State  = min(max(State,Pop_Lb),Pop_Ub);
