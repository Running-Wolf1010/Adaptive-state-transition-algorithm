function y = Schwefel_24(x)
% Schwefel 2.4 function
% 0 <= x <= 10
y = sum((x-1).^2 + (x(:,1)-x.^2).^2,2); 
