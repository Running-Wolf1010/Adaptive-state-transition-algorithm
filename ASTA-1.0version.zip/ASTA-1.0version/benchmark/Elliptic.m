function y = Elliptic(x)
% High conditioned elliptic function
% -100 <= x <= 100
[~, dim] = size(x);
y = sum((10^6).^(((1:dim)-1)./(dim-1)).*x.^2,2);
