function y = Zakharov(x)
% Zakharov function
% -5 <= x <= 10
[~,dim] = size(x);
y = sum(x.^2,2) + (sum(0.5*(1:dim).*x,2)).^2 + (sum(0.5*(1:dim).*x,2)).^4;
