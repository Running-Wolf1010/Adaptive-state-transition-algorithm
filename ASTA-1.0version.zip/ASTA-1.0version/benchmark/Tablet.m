function y = Tablet(x)
% Tablet function
% -100 <= x <= 100
[~,dim] = size(x);
y = 10^6*x(:,1).^2 + sum(x(:,2:dim).^6,2);
