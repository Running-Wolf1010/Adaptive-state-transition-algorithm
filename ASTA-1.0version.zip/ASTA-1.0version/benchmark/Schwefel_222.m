function y = Schwefel_222(x)
% Schwefel2.22 function
% -10 <= x <= 10
y=sum(abs(x),2)+prod(abs(x),2);
