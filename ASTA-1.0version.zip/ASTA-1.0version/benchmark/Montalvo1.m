function y = Montalvo1(x)
% Levy and Montalvo 1 function
% -10 <= x <= 10
[~,dim] = size(x);
y=pi/dim*(10*(sin(pi*(1+0.25.*(x(:,1)+1)))).^2 + sum((1+0.25.*(x(:,1:dim-1)+1)-1).^2.*(1+10*(sin(pi*(1+0.25.*(x(:,2:dim)+1)))).^2),2)+(1+0.25.*(x(:,dim)+1)-1).^2);
