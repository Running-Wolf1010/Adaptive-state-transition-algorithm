function y = Montalvo2(x)
% Levy and Montalvo 2 function
% -10 <= x <= 10
[~,dim] = size(x);
y=0.1*((sin(3*pi.*x(1))).^2+sum((x(:,1:dim-1)-1).^2.*(1+(sin(3*pi.*x(:,2:dim))).^2)+(x(dim)-1).^2.*(1+(sin(2*pi.*x(dim))).^2),2));
