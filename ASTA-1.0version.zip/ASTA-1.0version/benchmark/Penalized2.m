function y = Penalized2(x)
% Penalized 2 function
% -50 <= x <= 50
[~,dim] = size(x);
y=.1*((sin(3*pi.*x(:,1))).^2+sum((x(:,1:dim-1)-1).^2.*(1+(sin(3.*pi.*x(:,2:dim))).^2),2)+...
((x(:,dim)-1).^2).*(1+(sin(2.*pi.*x(:,dim))).^2))+sum(Ufun(x,5,100,4),2);
end

function y=Ufun(x,a,k,m)
y=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
end