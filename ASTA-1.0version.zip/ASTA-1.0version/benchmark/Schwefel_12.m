function y = Schwefel_12(x)
% Schwefel 1.2 function
% -100 <= x <= 100
dim=size(x,2);
y=0;
for i=1:dim
y=y+sum(x(:,1:i),2).^2;
end
