function y = Penalized1(x)
% Penalized 1 function
% -50 <= x <= 50
[~,dim] = size(x);
y=(pi/dim)*(10*((sin(pi*(1+(x(:,1)+1)./4))).^2)+sum((((x(:,1:dim-1)+1)./4).^2).*...
(1+10.*((sin(pi.*(1+(x(:,2:dim)+1)./4)))).^2),2)+((x(:,dim)+1)/4).^2)+sum(Ufun(x,10,100,4),2);
end

function y=Ufun(x,a,k,m)
y=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
end